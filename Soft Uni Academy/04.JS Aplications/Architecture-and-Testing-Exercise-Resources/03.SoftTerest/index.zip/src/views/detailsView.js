const details = document.getElementById("detailsView");


export function showDetails(ctx){
    ctx.renderer(details);
}