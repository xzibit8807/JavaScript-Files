const home = document.getElementById("homeView");

export function showHome(ctx){
    ctx.renderer(home);
}