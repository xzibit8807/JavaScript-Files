const login = document.getElementById("loginView");

export function showLogin(ctx){
    ctx.renderer(login);
}