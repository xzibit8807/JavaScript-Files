// api.js

import { html, render } from 'lit-html';

export function fetchCharacters() {
  // Изпраща заявка за получаване на информация за героите от сървъра
  // Тук може да добавите логика за извличане на данни от сървъра
}

export function addCharacter(characterData) {
  // Изпраща заявка за добавяне на герой към сървъра
  // Тук може да добавите логика за изпращане на данни към сървъра
}
