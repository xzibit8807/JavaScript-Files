export const baseURL = "http://localhost:3000";
export const loginUrl = baseURL + "users/login";
export const registerUrl = baseURL + "/users/register";
export const logoutURL = baseURL + "/users/logout";
