import { render, html } from "../node_modules/lit-html/lit-html.js";
import { getAllFacts } from "../services/data.js";

const root = document.querySelector("main");


function dashboardTemplate() { 
return html`          <!-- Dashboard page -->
<h3 class="heading">Our Cars</h3>
<section id="dashboard">
<!-- Display a div with information about every post (if any)-->

<section id="dashboard">
  ${cars.length == 0
    ? html`      
        <h3 class="nothing">Nothing to see yet</h3>`
    : cars.map(
      (e) => html`       
        <div class="car">
    <img src="${e.imageUrl}" alt="example1" />
    <h3 class="model">${e.model}</h3>
    <div class="specs">
    <div class="specs">
    <p class="price">${e.price}</p>
    <p class="weight">${e.weight}</p>
    <p class="top-speed">${e.speed}</p>
    <a class="details-btn" href="/details/${e._id}">More Info</a>
  </div>

`)}
</section>`;
}

export function dashboardView() {
  render(dashboardTemplate(), root);
}
