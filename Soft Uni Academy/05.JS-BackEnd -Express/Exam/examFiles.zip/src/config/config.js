module.exports =  {
    SECRET: `sadasdsfdgfd324revdfsd184tv5g3k4e75d`
};
